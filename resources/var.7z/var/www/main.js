function sayHello() {
	var name = document.getElementById("name").value;
	alert("Hello " + name);
}